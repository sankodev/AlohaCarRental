﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project6_KS_AlohaCarRental
{
    public partial class AlohaCarRental : Form
    {
        private decimal CalculateDailyCharge(int days, decimal chargePerDay)
        {
            decimal resultD = days * chargePerDay;
            return resultD;
        }

        private decimal CalculateMileageCharge(double mileage, decimal chargePerMile)
        {
            decimal resultM = (decimal)mileage * chargePerMile;
            return resultM;
        }
        public AlohaCarRental()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            customerTextBox.Clear();
            carTypeTextBox.Clear();
            mileageTextBox.Clear();
            daysTextBox.Clear();
            dailyChargeLabel.Text = "";
            mileageChargeLabel.Text = "";
            insurancePlanLabel.Text = "";
            insuranceCostLabel.Text = "";
            totalCostLabel.Text = "";
            customerTextBox.Focus();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //prep
            
            int carType, days;
            double mileage;
            decimal dailyCharge, mileageCharge, resultM, totalCost, resultD, insurancePlan1, insurancePlan2, insuranceCost;

            
            //vali
            if (!double.TryParse(mileageTextBox.Text, out mileage)|| mileage < 0)
            {
                MessageBox.Show("Enter in the mileage on the rental.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);  
            }
            if (!int.TryParse(daysTextBox.Text, out days)||days <0)
            {
               MessageBox.Show("Enter in the days on the rental.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); 
            }
            if (!int.TryParse(carTypeTextBox.Text, out carType)|| carType <1 || carType > 3) 
            {
               MessageBox.Show("Enter in the insurance plan type on the rental.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); 
            }

            if (carType ==1)
            {
                dailyCharge = 20.00m;
                mileageCharge = 0.25m;
            }
            else if (carType ==2)
            {
                dailyCharge = 25.00m;
                mileageCharge = 0.35m;
            }
            else
            {
                dailyCharge = 32.00m;
                mileageCharge = 0.40m;
            }
            resultD = CalculateDailyCharge(days, dailyCharge);
            dailyChargeLabel.Text = resultD.ToString("C");

            resultM = CalculateMileageCharge(mileage, mileageCharge);
            mileageChargeLabel.Text = resultM.ToString("C");

            insurancePlan2 = 15 + (1 * days);
            insurancePlan1 = resultD / 5;

            if (insurancePlan1 < 10)
            {
                insurancePlan1 = 10;
            }
            else
            {
                insurancePlan2 = resultD / 5;

            }

            if (insurancePlan1 < insurancePlan2)
            {
                insurancePlanLabel.Text = "1";
                
            }
            else
            {
                insurancePlanLabel.Text = "2";
            }
            insuranceCostLabel.Text = insurancePlan1.ToString("C");
            int n = Convert.ToInt32(resultM);
            totalCost = resultD + insurancePlan1 + n;
            totalCostLabel.Text = totalCost.ToString("C");

            if (totalCost >= 200m)
            {
                MessageBox.Show("That's a lot of cash going out your car door (no pun intended). If you're facing financial or legal problems.. you Better Call Saul [breaking bad]", "Better Call Saul!", MessageBoxButtons.OK, MessageBoxIcon.Error); 
            }

            customerTextBox.Focus();
            customerTextBox.SelectAll();
        }

        
    }
}
